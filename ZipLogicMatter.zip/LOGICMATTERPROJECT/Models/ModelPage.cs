﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace LOGICMATTERPROJECT.Models
{
    public class ModelPage
    {
        public class User
        {
            public int UserID { get; set; }
            public string UserName { get; set; }
            public string Password { get; set; }
            public string Role { get; set; }
            public bool IsActive { get; set; }
        }

        public class Seller
        {
            public int SellerID { get; set; }
            public int UserID { get; set; }
            public string CompanyName { get; set; }
            public string ContactNumber { get; set; }
        }

        public class Product
        {
            public int ProductID { get; set; }
            public int SellerID { get; set; }
            public string ProductName { get; set; }
            public string Description { get; set; }
            public decimal Price { get; set; }
            public string ImagePath { get; set; }
        }

        public class Cart
        {
            public int CartID { get; set; }
            public int BuyerID { get; set; }
            public int ProductID { get; set; }
            public int Quantity { get; set; }
        }

        public class Order
        {
            public int OrderID { get; set; }
            public int BuyerID { get; set; }
            public DateTime OrderDate { get; set; }
        }
    }
}