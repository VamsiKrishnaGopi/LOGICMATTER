﻿using LOGICMATTERPROJECT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LOGICMATTERPROJECT.Controllers
{

    public class LoginController : Controller
    {
        private ShoppingCartContext db = new ShoppingCartContext();
        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(string username, string password)
        {
            var user = db.Users.FirstOrDefault(u => u.UserName == username && u.Password == password && u.IsActive);
            if (user != null)
            {
                Session["UserID"] = user.UserID;
                Session["Role"] = user.Role;

                if (user.Role == "Admin")
                    return RedirectToAction("AdminDashboard", "Admin");
                else if (user.Role == "Seller")
                    return RedirectToAction("SellerDashboard", "Seller");
                else if (user.Role == "Buyer")
                    return RedirectToAction("Cart", "Buyer");
            }
            ViewBag.Message = "Invalid username or password!";
            return View();

        }

    }
}