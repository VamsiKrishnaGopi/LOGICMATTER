﻿using LOGICMATTERPROJECT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static LOGICMATTERPROJECT.Models.ModelPage;

namespace LOGICMATTERPROJECT.Controllers
{
    public class SellerController : Controller
    {
        private ShoppingCartContext db = new ShoppingCartContext();

        public ActionResult SellerDashboard()
        {
            int userId = (int)Session["UserID"];
            var seller = db.Sellers.FirstOrDefault(s => s.UserID == userId);
            var products = db.Products.Where(p => p.SellerID == seller.SellerID).ToList();
            return View(products);
        }

        [HttpGet]
        public ActionResult UploadProduct()
        {
            return View();
        }

        [HttpPost]
        public ActionResult UploadProduct(Product product)
        {
            if (ModelState.IsValid)
            {
                int userId = (int)Session["UserID"];
                var seller = db.Sellers.FirstOrDefault(s => s.UserID == userId);
                product.SellerID = seller.SellerID;

                db.Products.Add(product);
                db.SaveChanges();

                return RedirectToAction("SellerDashboard");
            }
            return View(product);
        }
    }
}