﻿using LOGICMATTERPROJECT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace LOGICMATTERPROJECT.Controllers
{
    public class AdminController : Controller
    {
        private ShoppingCartContext db = new ShoppingCartContext();

        public ActionResult AdminDashboard()
        {
            var users = db.Users.ToList();
            return View(users);
        }

        public ActionResult ToggleActivation(int id)
        {
            var user = db.Users.Find(id);
            if (user != null)
            {
                user.IsActive = !user.IsActive;
                db.SaveChanges();
            }
            return RedirectToAction("AdminDashboard");
        }
    }
}