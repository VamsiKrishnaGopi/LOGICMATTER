﻿using LOGICMATTERPROJECT.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static LOGICMATTERPROJECT.Models.ModelPage;

namespace LOGICMATTERPROJECT.Controllers
{
    public class AccountController : Controller
    {
        private ShoppingCartContext db = new ShoppingCartContext();

        [HttpGet]
        public ActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Register(User user)
        {
            if (ModelState.IsValid)
            {
                db.Users.Add(user);
                db.SaveChanges();

                if (user.Role == "Seller")
                {
                    Seller seller = new Seller
                    {
                        UserID = user.UserID,
                        CompanyName = Request["CompanyName"],
                        ContactNumber = Request["ContactNumber"]
                    };
                    db.Sellers.Add(seller);
                    db.SaveChanges();
                }

                return RedirectToAction("Login");
            }
            return View(user);
        }
    }
}